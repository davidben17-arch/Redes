# =========================================================
# CPM — Camino crítico (ruta más larga)
# Proyecto industrial con 8 actividades A-H
# II-1122 · Clase 12 · UCR Sede Alajuela
# =========================================================
#
# Formulación: el tiempo de cada evento (nodo) t[i]
# debe respetar las precedencias: t[j] >= t[i] + d[i,j]
# Se minimiza el tiempo del último evento.
# El óptimo del LP corresponde al CAMINO MÁS LARGO.

set EVENTOS;                          # nodos de la red de proyecto
set PRECEDENCIAS within {EVENTOS, EVENTOS};

param duracion {PRECEDENCIAS} >= 0;   # duración de la actividad i→j (días)
param inicio symbolic in EVENTOS;
param fin    symbolic in EVENTOS;

# Variable: tiempo de ocurrencia del evento (>= 0)
var t {EVENTOS} >= 0;

# Objetivo: minimizar el tiempo del evento final
minimize Duracion_proyecto: t[fin];

# Precedencias: el evento j ocurre después del evento i + duración
subject to Precedencia {(i,j) in PRECEDENCIAS}:
    t[j] >= t[i] + duracion[i,j];

# El proyecto inicia en t = 0
subject to Inicio_cero:
    t[inicio] = 0;
